from django.db import models

# Create your models here.
class Products_details(models.Model):
    name= models.CharField(max_length=50, help_text='Product Name',)
    img= models.ImageField()
    price= models.FloatField()
    desc= models.TextField()
    cate= models.CharField(max_length=50)

class Customers_details(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.EmailField()
    address = models.CharField(max_length=50)


class Sales_details(models.Model):
    uid = models.ForeignKey(Customers_details, on_delete=models.CASCADE)
    pid = models.ForeignKey(Products_details, on_delete=models.CASCADE)
    qty= models.IntegerField()
    total = models.FloatField()

from django.urls import path

from . import views

urlpatterns = [
    path('',views.info,name='info'),
    path('analysis',views.dashboard,name='dashboard'),
    path('sales',views.sales,name='sales'),
    path('finance',views.finance,name="finance"),
    path('data', views.pivot_data, name='pivot_data')
]

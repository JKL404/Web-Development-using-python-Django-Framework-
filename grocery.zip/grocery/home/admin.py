from django.contrib import admin
from .models import Products_details
from .models import Sales_details
from .models import Customers_details
# Register your models here.

admin.site.register(Products_details)
admin.site.register(Sales_details)
admin.site.register(Customers_details)
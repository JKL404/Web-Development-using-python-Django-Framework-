from django.http import JsonResponse
from django.shortcuts import render
from django.core import serializers
from .models import *
# Create your views here.

def dashboard(request):
    return render(request,'dashboard.html',{})

def add(request):
    val1= int(request.POST['n1'])
    val2= int(request.POST['n2'])
    res= val1 + val2
    return render(request,'result.html',{'result':res})

def sales(request):
    
    return render(request,"index.html")

def info(request):
    products = Products_details.objects.all()
    pur = Sales_details.objects.all().select_related()
    customer_count = Customers_details.objects.filter().count()
    product_count = Products_details.objects.filter().count()
    order_count = Sales_details.objects.filter().count()
    return render(request,"dashboard-sales.html",{'cust':customer_count,'prod':product_count,'ord':order_count,'products':products,'pur':pur})

def finance(request):
    return render(request,"dashboard-finance.html")

def pivot_data(request):
    dataset = Sales_details.objects.all()
    data = serializers.serialize('json', dataset)
    return JsonResponse(data, safe=False)